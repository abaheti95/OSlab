#include <stdio.h>
#include <stdlib.h>
int main()
{
	system("clear");
	printf("COMMENCING CONFERENCE: RESPOND\n");
	return 0;
}